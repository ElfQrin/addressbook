<?
# release information

$project_n='EQ_AddressBook'; $project_v='r2016-10-16'; # fr2016-10-16

?>