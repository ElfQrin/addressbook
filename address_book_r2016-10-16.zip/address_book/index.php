<?
define('PAGETITLE','Address Book - Home');
include('site_header.php');

echo '<center>'.'<h1>'.'Welcome'.'</h1>'.'</center>';

include('site_footer.php');
?>