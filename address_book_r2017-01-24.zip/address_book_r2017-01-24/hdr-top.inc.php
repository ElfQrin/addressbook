<? if (!defined('IN_ENGINE')) {die('forbidden');} ?>
<table border="0" align="center" cellpadding="0" cellspacing="0">
<tr>
<td align="center">
<?
echo '<strong>'.$edge_project_name.'</strong>';
?>
</td>
</tr>
</table>