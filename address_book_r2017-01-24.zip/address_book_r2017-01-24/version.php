<?
# release information

$project_n='EQ_AddressBook'; $project_v='r2017-01-24'; # fr2016-10-16

?>