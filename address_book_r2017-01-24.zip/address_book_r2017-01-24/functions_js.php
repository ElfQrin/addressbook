<script language="JavaScript" type="text/javascript">
<!--
function submitonce(theform){
// if IE 4+ or NS 6+
if (document.all||document.getElementById) {
for (i=0;i<theform.length;i++) {
var tempobj=theform.elements[i];
if (tempobj.type.toLowerCase()=="submit"||tempobj.type.toLowerCase()=="reset") {tempobj.disabled=true;}
}
}
}

function selloc(frm,obj) {
// document.console.x_var.value=document.console.sel_x_var.value;
a=eval('document.'+frm+'.'+obj);
b=eval('document.'+frm+'.sel_'+obj);
a.value=b.value;
}

// -->
</script>
