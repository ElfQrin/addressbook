<?
# release information

$project_n='EQ_AddressBook'; $project_v='r2016-10-19'; # fr2016-10-16

?>